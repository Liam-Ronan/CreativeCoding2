
class Journey {
    constructor(_fromCity, _fromLat, _fromLng, _toCity, _toLat, _toLng, _distance) {
        this.fromCity = _fromCity
        this.fromLat = _fromLat;
        this.fromLng = _fromLng;
        this.toCity = _toCity;
        this.toLat = _toLat;
        this.toLng =  _toLng;
        this.distance = _distance;
    }

}